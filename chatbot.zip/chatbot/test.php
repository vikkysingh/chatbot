<?php
echo 'It works';
?>